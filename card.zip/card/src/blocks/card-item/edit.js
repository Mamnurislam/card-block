import { __ } from '@wordpress/i18n';
import {
	useBlockProps,
	InspectorControls,
	MediaUpload,
	RichText,
} from '@wordpress/block-editor';
import { PanelBody, ColorPalette, RangeControl } from '@wordpress/components';
const { Fragment } = wp.element;

// editor style
import './editor.scss';

// colors
import colors from '../../utilities/colors-palette';

export default function Edit({ attributes, setAttributes }) {
	const {
		color,
		btnbgcolor,
		url,
		btnradius,
		btnwidth,
		alt,
		id,
		btnName,
		btnlink,
	} = attributes;
	return (
		<Fragment>
			<InspectorControls>
				<PanelBody
					title={__('BTN COLOR', 'boilerplate')}
					initialOpen={false}
				>
					<p className="custom__editor__label">
						{__('Btn Color', 'boilerplate')}
					</p>
					<ColorPalette
						colors={colors}
						value={color}
						onChange={(newColor) =>
							setAttributes({ color: newColor })
						}
					/>
				</PanelBody>
				<PanelBody
					title={__('Btn Bg color', 'boilerplate')}
					initialOpen={false}
				>
					<p className="custom__editor__label">
						{__('Btn Background Color', 'boilerplate')}
					</p>
					<ColorPalette
						colors={colors}
						value={color}
						onChange={(newColor) =>
							setAttributes({ btnbgcolor: newColor })
						}
					/>
				</PanelBody>

				<PanelBody initialOpen={true} title="Button Link">
					<div className="linktab">
						<RichText
							tagName="p"
							value={btnlink}
							onChange={(value) =>
								setAttributes({ btnlink: value })
							}
							placeholder="Link Here"
						/>
					</div>
				</PanelBody>
				<PanelBody title="Button setting" initialOpen={false}>
					<RangeControl
						label="Radius"
						value={btnradius}
						onChange={(value) =>
							setAttributes({ btnradius: value })
						}
						min={0}
						max={100}
					/>
					<p>Button width</p>
					<RangeControl
						label="Button Length"
						value={btnwidth}
						onChange={(value) => setAttributes({ btnwidth: value })}
						min={0}
						max={100}
					/>
				</PanelBody>
			</InspectorControls>

			<div {...useBlockProps()}>
				<div className="card-item">
					{url ? (
						<img src={url} alt="pic" />
					) : (
						<MediaUpload
							onSelect={(media) =>
								setAttributes({
									url: media.url,
								})
							}
							value={url}
							render={({ open }) => (
								<button onClick={open}>upload Image</button>
							)}
						/>
					)}
					<RichText
						tagName="p"
						value={btnName}
						onChange={(value) => setAttributes({ btnName: value })}
						placeholder="button text"
						style={{
							color,
							background: btnbgcolor,
							width: `${btnwidth}%`,
							padding: '6px',
							textAlign: 'center',
							borderRadius: `${btnradius}px`,
						}}
					/>
				</div>
			</div>
		</Fragment>
	);
}
