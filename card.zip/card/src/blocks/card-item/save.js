// import { __ } from '@wordpress/i18n';
import { useBlockProps } from '@wordpress/block-editor';

export default function save({ attributes }) {
	const {
		url,
		color,
		btnbgcolor,
		btnradius,
		btnwidth,
		alt,
		id,
		btnName,
		btnlink,
	} = attributes;

	return (
		<div {...useBlockProps.save()}>
			<div className="card-item">
				{url && <img src={url} alt="pic" />}
				{btnName && (
					<a
						href={btnlink}
						style={{
							color,
							background: btnbgcolor,
							width: `${btnwidth}%`,
							padding: '6px',
							textAlign: 'center',
							borderRadius: `${btnradius}px`,
							display: 'block',
							margin: '6px 0',
						}}
					>
						{btnName}
					</a>
				)}
			</div>
		</div>
	);
}
