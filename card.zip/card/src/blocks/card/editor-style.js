import styled from 'styled-components';

const CardBlock = styled.div`
	display: grid;

	@media (min-width: 768px) and (max-width: 1024px) {
		.block-editor-block-list__layout {
			background: ${(props) => props.bg};
			grid-template-columns: repeat(3, 1fr);
		}
	}
`;

export default CardBlock;
