import { __ } from '@wordpress/i18n';
import {
	useBlockProps,
	InspectorControls,
	InnerBlocks,
} from '@wordpress/block-editor';
import { PanelBody, ColorPalette, TabPanel } from '@wordpress/components';
const { Fragment } = wp.element;

// editor style
import './editor.scss';
//admin editor css
// editor style
import '../../utilities/admin/editor.scss';
// colors

//colorcontrol

import ColorControl from '../../utilities/components/colorcontrol/colorcontrol';

//import style component
import CardBlock from './editor-style';

import colors from '../../utilities/colors-palette';

//import style inputcontrols
import Inputcontrol from '../../utilities/inputcontrol/inputcontrol';

export default function Edit({ attributes, setAttributes, clientId }) {
	const { color, containerBg, device, id, bg } = attributes;
	setAttributes({ id: 'card' + clientId.slice(0, 6) });
	return (
		<Fragment>
			<InspectorControls>
				<TabPanel
					className="etb-tab-panel"
					initialTabName="etb_general"
					tabs={[
						{
							name: 'etb_general',
							title: __('General', 'easy-testimonial-blocks'),
							className: 'etb_tab etb_general',
						},
						{
							name: 'etb_advanced',
							title: __('Advanced', 'easy-testimonial-blocks'),
							className: 'etb_tab etb_advanced',
						},
					]}
				>
					{(tab) => {
						if (tab.name === 'etb_general') {
							return (
								<Fragment>
									<PanelBody initialOpen={true}>
										<ColorControl
											label={__(
												'Container Background',
												'easy-testimonial-blocks'
											)}
											colorValue={containerBg}
											colorName="containerBg"
											setAttributes={setAttributes}
											disableAlpha={true}
										/>
									</PanelBody>
									<PanelBody>
										<Inputcontrol
											label={__('Device', 'card')}
											atributes={device}
											atributeName="device"
											setAtributes={setAttributes}
										/>
									</PanelBody>
								</Fragment>
							);
						} else if (tab.name === 'etb_advanced') {
							return <div>hi</div>;
						}
					}}
				</TabPanel>

				<PanelBody
					title={__('Settings', 'boilerplate')}
					initialOpen={true}
				>
					<p className="custom__editor__label">
						{__('Text Color', 'boilerplate')}
					</p>
					<ColorPalette
						colors={colors}
						value={color}
						onChange={(newColor) =>
							setAttributes({ color: newColor })
						}
					/>
				</PanelBody>
			</InspectorControls>

			<CardBlock {...useBlockProps()} device={device} bg={bg}>
				<div className="cb-image-card">
					<InnerBlocks
						allowedBlocks={['cb/card-item']}
						template={[
							['cb/card-item'],
							['cb/card-item'],
							['cb/card-item'],
						]}
						renderAppender={InnerBlocks.ButtonBlockAppender}
					/>
				</div>
			</CardBlock>
		</Fragment>
	);
}
