/**
 * Includes all blocks root files
 */

import './blocks/card/index';
import './blocks/card-item/index';
