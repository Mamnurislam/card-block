import { __ } from '@wordpress/i18n';
import { RangeControl } from '@wordpress/components';
import { useState } from '@wordpress/element';

import './inputcontrol.scss';
const Inputcontrol = ({
	label,
	atributes,
	atributeName,
	setAtributes,
	min,
	max,
}) => {
	const [device, setDevice] = useState('desktop');

	return (
		<div className="device-wrap">
			<p className="label">{label}</p>
			<div className="device">
				<button onClick={() => setDevice('desktop')}>desktop</button>
				<button onClick={() => setDevice('tablet')}>tablet</button>
				<button onClick={() => setDevice('mobile')}>mobile</button>
			</div>
			<div className="device-value">
				{device === 'desktop' && (
					<RangeControl
						label="DeskTop"
						value={atributes.desktop}
						onChange={(value) =>
							setAtributes({
								[atributeName]: {
									...atributes,
									desktop: value,
								},
							})
						}
						min={1}
						max={6}
					/>
				)}
				{device === 'tablet' && (
					<RangeControl
						label="Tablet"
						value={atributes.tablet}
						onChange={(value) =>
							setAtributes({
								[atributeName]: {
									...atributes,
									tablet: value,
								},
							})
						}
						min={1}
						max={6}
					/>
				)}
				{device === 'mobile' && (
					<RangeControl
						label="Mobile"
						value={atributes.mobile}
						onChange={(value) =>
							setAtributes({
								[atributeName]: {
									...atributes,
									mobile: value,
								},
							})
						}
						min={1}
						max={6}
					/>
				)}
			</div>
		</div>
	);
};

export default Inputcontrol;
